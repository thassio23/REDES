#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <inttypes.h>
#include <zlib.h>
#include "b64.h"


 
int main(int argc, char *argv[ ]) {

//--------------------Operação a ser executada---------------------------//

    char *ponteiroe,*ponteiror,*ponteiroc,*ponteiro;
    int flag;
    ponteiroe = "-e";
    ponteiror = "-r";
    ponteiroc = "-c";
    if(strcmp(argv[1], ponteiroe) == 0){
    ponteiro = "env";   
    flag =1;
    }
    if (strcmp(argv[1], ponteiror) == 0){
    ponteiro = "rec";
    flag =2;   
    }
    if(strcmp(argv[1], ponteiroc) == 0){
    ponteiro = "cal"; 
    flag=3;
    }

//---------------------Lê determinado arquivo de texto-------------------//
    char arquivo[1024];   
    if(flag == 1){
    FILE *fp;
    
    fp = fopen(argv[2] , "r"); //NOME DO ARQUIVO .txt
    if(fp == NULL) {
    perror("Error opening file");
    return(-1);
    }
    if( fgets (arquivo, 1024, fp)!=NULL ) {
    }
    fclose(fp);
    }



//-------------------------------------------------------------------------//

    int sockfd;
    char buffer[1024];

    struct sockaddr_in     servaddr;

    struct timeval tv;

    struct timeval timeout={1,0}; //timeout 1 segundo

    // Creating socket file descriptor
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {     // SOCK_DIAGRAN DEFINE QUE O TIPO DE TRANSPORTE SERÁ UDP
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }   
 
    memset(&servaddr, 0, sizeof(servaddr));
     
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(6100);               // DETERMINA A PORTA PELA QUAL SERÁ ENVIADA A MENSAGEM
    servaddr.sin_addr.s_addr = inet_addr(argv[3]); // IP DO SERVIDOR
     
//-------------------------------Determinando Payload-------------------------------------------//
    char *operacao;

    int tamanho;
    int tamanhodoarquivo;
    char tamanhodoarquivostring[3];
    operacao = ponteiro;
    char mensagem[1024];

    if(flag == 1){
    strcpy(mensagem, operacao);
    strcat(mensagem, ",");
    strcat(mensagem, "000");
    strcat(mensagem, ",");
    char crcdoarquivo[10];
    unsigned long  crc = crc32(0L, Z_NULL, 0);
    crc = crc32(crc, (const unsigned char*)arquivo, strlen(arquivo));
    sprintf(crcdoarquivo, "%lX", crc);
    strcat(mensagem, "0x");
    strcat(mensagem, crcdoarquivo);
    strcat(mensagem, ",");

    char *enc = b64_encode(arquivo, strlen(arquivo));
    int o = 0;
    while(enc[o] != '\0'){
    arquivo[o] = enc[o];
    o++;
    }

    strcat(mensagem, arquivo);

    sprintf(tamanhodoarquivostring, "%ld", strlen(arquivo)-1);

    if((strlen(arquivo)-1) <= 9){
    mensagem[6] = tamanhodoarquivostring[0];
    }

    if((strlen(arquivo)-1) >=10 && (strlen(arquivo)-1) <= 99){
    for(int b = 5;b<7;b++){
    mensagem[5] = tamanhodoarquivostring[b-5];
    }
    }
    if((strlen(arquivo)-1) >=100){
    for(int b = 4;b<7;b++){
    mensagem[4] = tamanhodoarquivostring[b-4];
    }
    
    }


    }



    if(flag == 2){
    
    strcpy(mensagem, operacao);
    strcat(mensagem, ",");
    strcat(mensagem, "0");
    strcat(mensagem, ",");    
    strcat(mensagem, "0xFFFFFFFF");
    strcat(mensagem, ",");
    strcat(mensagem, argv[2]);    
    }

    if(flag == 3){

    strcpy(mensagem, operacao);
    strcat(mensagem, ",");
    strcat(mensagem, "0");
    strcat(mensagem, ",");    
    strcat(mensagem, "0xFFFFFFFF");
    strcat(mensagem, ","); 
    strcat(mensagem, " "); 
    strcat(mensagem, ",");
    strcat(mensagem, argv[2]);
    }
    
    tamanhodoarquivo = strlen(mensagem) -1;

    int n, len;
    int tentanumero = 0;
    tentadenovo:
//------------------------------Envio da mensagem------------------------------------//

    printf("Mensagem enviada: %s\n", mensagem);
    sendto(sockfd, (const char *)mensagem, strlen(mensagem),
        MSG_CONFIRM, (const struct sockaddr *) &servaddr, 
            sizeof(servaddr));


    
if(flag == 1){
    
    setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(char*)&timeout,sizeof(struct timeval));
    n = recvfrom(sockfd, (char *)buffer, 1024, MSG_WAITALL, (struct sockaddr *) &servaddr, &len);
    if (n >= 0) {
    printf("Mensagem Recebida: %s\n", buffer);
    }
    else{
    printf("Problema de conexão com servidor\n");
    if(tentanumero == 3){
    goto fim;    
    }
    tentanumero++;
    goto tentadenovo;
    }
    buffer[n] = '\0';
}

//------------------------------recebe arquivo do servidor---------------------------//
  
    if(flag == 2){

    MensagemErrada:

    setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(char*)&timeout,sizeof(struct timeval));
    n = recvfrom(sockfd, (char *)buffer, 1024, MSG_WAITALL, (struct sockaddr *) &servaddr, &len);
    if (n >= 0) {
    printf("Mensagem Recebida: %s\n", buffer);
    }
    else{
    printf("Problema de conexão com servidor\n");

    if(tentanumero == 3){
    goto fim;    
    }
    tentanumero++;
    goto tentadenovo;
    
    }

    buffer[n] = '\0';

    char mensagemtexto[3000];
    char mensagemcrc[8];
    char mensagem1[1024];
    int a = 0;

    for(int i = 0;i<8;i++){
    mensagemcrc[i] = buffer[i+10];
    }

    int loop = 0;

    while(buffer[loop+19] != '\0'){
    mensagemtexto[loop] = buffer[loop+19];
    loop++;
    }

    char *dec = b64_decode(mensagemtexto, strlen(mensagemtexto));


    char crcdoarquivo[10];



    unsigned long  crc = crc32(0L, Z_NULL, 0);
    crc = crc32(crc, (const unsigned char*)dec, strlen(dec));
    sprintf(crcdoarquivo, "%lX", crc);


        printf("CRC do arquivo codificado: %s\n", crcdoarquivo);

    printf("Mensagem em Base64: %s\n", mensagemtexto);

    printf("Mensagem decodificada: %s\n", dec);

    for(int i = 0;i<8;i++){
    if(mensagemcrc[i] == crcdoarquivo[i]){
    a++;
    }
    }

    
    if(a == 8){
    
    FILE *fp1;
    
    fp1 = fopen("teste_recebido_cliente.txt", "w+");
    fputs(dec, fp1);
    fclose(fp1);

    }
    else{

    if(n == 0){
    strcpy(mensagem1, "res");
    strcat(mensagem1, ",");
    strcat(mensagem1, "-1");
    strcat(mensagem1, ",");
    strcat(mensagem1, "0xFFFFFFFF");

    sendto(sockfd, (const char *)mensagem1, strlen(mensagem1),
        MSG_CONFIRM, (const struct sockaddr *) &servaddr, 
            sizeof(servaddr));
    goto MensagemErrada;
    }
    }
    
    }
    
    
    if(flag == 3 ){


    setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(char*)&timeout,sizeof(struct timeval));
    n = recvfrom(sockfd, (char *)buffer, 1024, MSG_WAITALL, (struct sockaddr *) &servaddr, &len);
    if (n >= 0) {
    printf("Mensagem Recebida: %s\n", buffer);
    }
    else{
    printf("Problema de conexão com servidor\n");

    if(tentanumero == 3){
    goto fim;    
    }
    tentanumero++;
    goto tentadenovo;
    
    }

    buffer[n] = '\0';

    char mensagemtexto[1024];
    char mensagemcrc[10];
    char mensagem1[1024];
    int a = 0;

    for(int i = 0;i<8;i++){
    mensagemcrc[i] = buffer[i+10];
    }

    char crcdoarquivo[10];
    unsigned long  crc = crc32(0L, Z_NULL, 0);
    crc = crc32(crc, (const unsigned char*)mensagemtexto, strlen(mensagemtexto));
    sprintf(crcdoarquivo, "%lX", crc);

    if(n == 0){
    strcpy(mensagem1, "res");
    strcat(mensagem1, ",");
    strcat(mensagem1, "-1");
    strcat(mensagem1, ",");
    strcat(mensagem1, "0xFFFFFFFF");


    sendto(sockfd, (const char *)mensagem1, strlen(mensagem1),
        MSG_CONFIRM, (const struct sockaddr *) &servaddr, 
            sizeof(servaddr));
    goto MensagemErrada;
    
    }

    }

    fim:
    close(sockfd);
    return 0;
}
