#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <inttypes.h>
#include <zlib.h>
#include "b64.h"

#define PORT     6100
 
// Driver code
int main() {
    
    int sockfd;
    struct sockaddr_in servaddr, cliaddr;
    int desiste;

    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }
     
    memset(&servaddr, 0, sizeof(servaddr));
    memset(&cliaddr, 0, sizeof(cliaddr));
     
    servaddr.sin_family    = AF_INET; // IPv4
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);
     
    
    if ( bind(sockfd, (const struct sockaddr *)&servaddr, 
            sizeof(servaddr)) < 0 )
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    aqui: while(1){
    char mensagemtexto[1024];

    for(int i = 0; i<1024;i++){
    mensagemtexto[i] = '\0';    
    }
    char buffer[1024];
    int len, n;
        int contador1 = 0;
        int contador2 = 0;
        int contador3 = 0;
    n = recvfrom(sockfd, (char *)buffer, 1024, 
                MSG_WAITALL, ( struct sockaddr *) &cliaddr,
                &len);
    buffer[n] = '\0';
    
    printf("Mensagem Recebida: %s\n", buffer);
//----------------------------------------------------------------------------------------------------------//

    char operacao[3];
    char *ponteiroe = "env";
    char *ponteiror = "rec";
    char *ponteiroc = "cal";



    for(int i = 0;i<3;i++){
    operacao[i] = buffer[i];
    }

    for(int i = 0;i<3;i++){
    if(operacao[i] == ponteiroe[i]){
    contador1++;    
    }
    if(operacao[i] == ponteiror[i]){
    contador2++;    
    }
    if(operacao[i] == ponteiroc[i]){
    contador3++;    
    }

    }
//----------------------------Recebe arquivo do cliente-----------------------------------//
    
    if(contador1 == 3){
    char mensagemcrc[8];
    
    for(int i = 0;i<8;i++){
    mensagemcrc[i] = buffer[i+10];
    }

    int loop = 0;

    while(buffer[loop+19] != '\0'){
    mensagemtexto[loop] = buffer[loop+19];
    loop++;
    }

    char crcdoarquivo[10];
    char *dec = b64_decode(mensagemtexto, strlen(mensagemtexto));
    unsigned long  crc = crc32(0L, Z_NULL, 0);
    crc = crc32(crc, (const unsigned char*)dec, strlen(dec));
    sprintf(crcdoarquivo, "%lX", crc);


    int a = 0;
    for(int i = 0;i<8;i++){
    if(mensagemcrc[i] == crcdoarquivo[i]){
    a++;
    }

    }
    char mensagem[1024];

    if(a == 8){
    FILE *fp;
    fp = fopen("teste_recebido.txt", "w+");
    fputs(dec, fp);
    fclose(fp);

    

    strcpy(mensagem, "res");
    strcat(mensagem, ",");
    strcat(mensagem, "0");
    strcat(mensagem, ",");

    char crcdoarquivo1[10];
    unsigned long  crc1 = crc32(0L, Z_NULL, 0);
    crc1 = crc32(crc1, (const unsigned char*)mensagemtexto, strlen(mensagemtexto));
    sprintf(crcdoarquivo1, "%lX", crc1);

    
    strcat(mensagem, "0x");
    strcat(mensagem, crcdoarquivo1);

    printf("Mensagem Enviada: %s\n", mensagem);

    sendto(sockfd, (const char *)mensagem, strlen(mensagem),MSG_CONFIRM,(const struct sockaddr *) &cliaddr, len);

    }

    else{
    strcpy(mensagem, "res");
    strcat(mensagem, ",");
    strcat(mensagem, "-1");
    strcat(mensagem, ",");
    strcat(mensagem, "0xFFFFFFFF");

    }  
    }

//-----------------------------------envia arquivo para cliente--------------------------------------------//

    if(contador2 == 3){
    int loop = 0;
    char nomedoarquivo[1024];
    char m1[1024];
    char arquivo2[1024];  
    char tamanhodoarquivostring[3];
    char *mensagemderro= "res,-1,0xFFFFFFFF";

    while(buffer[loop+17] != '.'){
    mensagemtexto[loop] = buffer[loop+17];
    loop++;
    }

    strcpy(nomedoarquivo, mensagemtexto);
    strcat(nomedoarquivo, ".txt");
   

    FILE *fp1;
    fp1 = fopen(nomedoarquivo , "r"); //NOME DO ARQUIVO .txt
    if(fp1 == NULL) {
    sendto(sockfd, (const char *)mensagemderro, strlen(mensagemderro),MSG_CONFIRM,(const struct sockaddr *) &cliaddr, sizeof(servaddr));
    goto aqui;
    }
    if( fgets (arquivo2, 1024, fp1)!=NULL ) {
    }
    fclose(fp1);
    strcpy(m1, "res");
    strcat(m1, ",");
    strcat(m1, "000");
    strcat(m1, ",");
    char crcdoarquivo[10];
    unsigned long  crc = crc32(0L, Z_NULL, 0);
    crc = crc32(crc, (const unsigned char*)arquivo2, strlen(arquivo2));
    sprintf(crcdoarquivo, "%lX", crc);
    strcat(m1, "0x");
    strcat(m1, crcdoarquivo);
    strcat(m1, ",");


    char *enc = b64_encode(arquivo2, strlen(arquivo2));

    int o = 0;
    while(enc[o] != '\0'){
    arquivo2[o] = enc[o];
    o++;
    }


    strcat(m1, arquivo2);

    sprintf(tamanhodoarquivostring, "%ld", strlen(arquivo2)-1);

    if((strlen(arquivo2)-1) <= 9){
    m1[6] = tamanhodoarquivostring[0];
    }

    if((strlen(arquivo2)-1) >=10 && (strlen(arquivo2)-1) <= 99){
    for(int b = 5;b<7;b++){
    m1[b] = tamanhodoarquivostring[b-5];
    }
    }
    if((strlen(arquivo2)-1) >=100){
    for(int b = 4;b<7;b++){
    m1[b] = tamanhodoarquivostring[b-4];
    }
    
    }

    printf("Mensagem Enviada: %s\n", m1);
    sendto(sockfd, (const char *)m1, strlen(m1),MSG_CONFIRM,(const struct sockaddr *) &cliaddr, sizeof(servaddr));

    
    }

//-------------------------------------------------CAL----------------------------------------------//

    if(contador3 == 3){

    int loop = 0;
    char nomedoarquivo[1024];
    char m1[1024];
    char arquivo2[1024];  
    char *mensagemderro= "res,-1,0xFFFFFFFF";


    while(buffer[loop+19] != '.'){
    mensagemtexto[loop] = buffer[loop+19];
    loop++;
    }

    strcpy(nomedoarquivo, mensagemtexto);
    strcat(nomedoarquivo, ".txt");

    

    FILE *fp2;
    fp2 = fopen(nomedoarquivo , "r"); //NOME DO ARQUIVO .txt
    if(fp2 == NULL) {
    sendto(sockfd, (const char *)mensagemderro, strlen(mensagemderro),MSG_CONFIRM,(const struct sockaddr *) &cliaddr, sizeof(servaddr));
    goto aqui;
    }
    if( fgets (arquivo2, 1024, fp2)!=NULL ) {
    
    fclose(fp2);
    strcpy(m1, "res");
    strcat(m1, ",");
    strcat(m1, "0");
    strcat(m1, ",");
    char crcdoarquivo[10];  
    unsigned long  crc = crc32(0L, Z_NULL, 0);
    crc = crc32(crc, (const unsigned char*)arquivo2, strlen(arquivo2));
    sprintf(crcdoarquivo, "%lX", crc);
    strcat(m1, "0x");
    strcat(m1, crcdoarquivo);
    }


    printf("Mensagem Enviada: %s\n", m1);
    sendto(sockfd, (const char *)m1, strlen(m1),MSG_CONFIRM,(const struct sockaddr *) &cliaddr, sizeof(servaddr));

    
    }
    
    }

    return 0;
}
